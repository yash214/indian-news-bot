"""Shared platform helpers."""

